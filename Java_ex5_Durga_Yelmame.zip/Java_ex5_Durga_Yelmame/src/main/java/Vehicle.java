/**
 * identification codde is common between customer and vehicle data.
 * rented_or_not will show the rent status(true for rented, false for not rented)
 *
 */
public class Vehicle {
    private String identification_code,model,brand,license_plate;
    private int number_of_seats;
    private boolean rented_or_not;
    private int rent_per_day;

    public Vehicle(String identification_code, String model, String brand, String license_plate, int number_of_seats, boolean rented_or_not,int rent_per_day) {
        this.identification_code = identification_code;
        this.model = model;
        this.brand = brand;
        this.license_plate = license_plate;
        this.number_of_seats = number_of_seats;
        this.rented_or_not = rented_or_not;
        this.rent_per_day=rent_per_day;
    }

    public int getRent_per_day() {
        return rent_per_day;
    }



    public String getIdentification_code() {
        return identification_code;
    }



    public String getModel() {
        return model;
    }



    public String getBrand() {
        return brand;
    }



    public String getLicense_plate() {
        return license_plate;
    }


    public int getNumber_of_seats() {
        return number_of_seats;
    }


    public boolean isRented_or_not() {
        return rented_or_not;
    }

    public void setRented_or_not(boolean rented_or_not) {
        this.rented_or_not = rented_or_not;
    }
}
