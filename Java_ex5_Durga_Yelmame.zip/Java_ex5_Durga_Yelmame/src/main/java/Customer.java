/**
 * customer id is UNIQUE
 * Vehicle identification code is a common field between customer and vehicle.
 * start date and end date is date the vehicle will be rented
 */
public class Customer {
    private String Name_of_customer, vehicle_identification_code, start_date,end_date;
    private int Phone_number,customer_id;


    public Customer(String name_of_customer, String vehicle_identification_code, int phone_number, int customer_id, String Start_Full_Date, String End_Full_Date) {
        Name_of_customer = name_of_customer;
        this.vehicle_identification_code = vehicle_identification_code;
        Phone_number = phone_number;
        this.customer_id = customer_id;
        start_date=Start_Full_Date;
        end_date=End_Full_Date;


    }

    public String getStart_date() {
        return start_date;
    }



    public String getEnd_date() {
        return end_date;
    }



    public String getName_of_customer() {
        return Name_of_customer;
    }



    public String getVehicle_identification_code() {
        return vehicle_identification_code;
    }



    public int getPhone_number() {
        return Phone_number;
    }



    public int getCustomer_id() {
        return customer_id;
    }


}
