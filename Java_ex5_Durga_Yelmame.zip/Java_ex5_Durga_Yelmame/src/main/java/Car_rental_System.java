import java.io.*;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.*;

/**
 * This class contains all main methods.
 * It contains all data of customer and vehicle in csv and arraylist.
 */
public class Car_rental_System {

    ArrayList<Customer> Customers=new ArrayList<>();
    ArrayList<Vehicle> Vehicles=new ArrayList<>();
    File Vehicle_File,Customer_File;


    /**
     * Constructor is used for file creation.
     * if file does not exist it will create new file (Vehicle: Vehicle_data.csv and customer: Customer_data.csv)
     * if file already exists it will read all data from file and store it in ArrayList.
     *
     * Data from file is stored in arrayList so that other operations can be performed easily, and for every operation we don't need to read file.
     *
     * Same steps are performed twice. First time for vehicle data file, second time for customer data file.
     */
    public Car_rental_System() {
        //for vehicle file and vehicle arraylist
          try {

            Vehicle_File = new File("Vehicle_data.csv");

            if (Vehicle_File.createNewFile()){
             System.out.println("Vehicle File is created!");
            }else{
                System.out.println("Vehicle File already exists.");
                try{

                    Scanner sc = new Scanner(new File("Vehicle_data.csv"));
                    sc.useDelimiter("\n");
                   Vehicle vehicle_obj;
                    sc.nextLine(); //Skip reading Headers;
                    while (sc.hasNextLine())
                    {
                        String data=sc.nextLine();
                        String[] array_of_data = data.split(",");
                        vehicle_obj=new Vehicle(array_of_data[0],array_of_data[2],array_of_data[1],array_of_data[4],Integer.parseInt(array_of_data[3]),Boolean.parseBoolean(array_of_data[5]),Integer.parseInt(array_of_data[6]));
                        Vehicles.add(vehicle_obj);
                    }
                    sc.close();
                }catch(FileNotFoundException e)
                {
                    System.out.println("Error_1: The file mentioned is not found. \n Solutions: \n1. Store at proper location.\n2. Check name of file.");
                }
            }

        } catch (IOException e) {
            e.printStackTrace();
        }
//For Customer file and customer arraylist
        try {

            Customer_File = new File("Customer_data.csv");

            if (Customer_File.createNewFile()){

                System.out.println("Customer File is created!");
            }else{
                System.out.println("Customer File already exists.");
                try{

                    Scanner sc = new Scanner(new File("Customer_data.csv"));
                    sc.useDelimiter("\n");
                    Customer customer_obj;
                    sc.nextLine(); //Skip reading Headers;
                    while (sc.hasNextLine())
                    {
                        String data=sc.nextLine();
                        String[] array_of_data = data.split(",");
                        customer_obj=new Customer(array_of_data[0],array_of_data[1],Integer.parseInt(array_of_data[2]),Integer.parseInt(array_of_data[3]),array_of_data[4],array_of_data[5]);
                        Customers.add(customer_obj);
                    }
                    sc.close();
                }catch(FileNotFoundException e)
                {
                    System.out.println("Error_2: The file mentioned is not found. \n Solutions: \n1. Store at proper location.\n2. Check name of file.");
                }
            }

        } catch (IOException e) {
            e.printStackTrace();
        }


    }

    /** addVehicle()
     * Take all parameters required to create Vehicle object and then calls vehicle constructor.
     *
     * It checks if the database already has a vehicle with same identification code, if yes -> it will display error and vehicle will not be added.
     * if no-> Vehicle will be added to database.
     *
     * Identification code should be UNIQUE.
     */
    public void addVehicle(String identification_code, String model, String brand, String license_plate, int number_of_seats, boolean rented_or_not,int rent_per_day)
    {
        Vehicle vehicle_obj=findVehicle(identification_code);
        if(vehicle_obj==null) {
            Vehicle vehicle = new Vehicle(identification_code, model, brand, license_plate, number_of_seats, rented_or_not, rent_per_day);
            Vehicles.add(vehicle);
            write_to_file();
            System.out.println("Successfully added vehicle to system!!!");
        }
        else
        {
            System.out.println("ERROR: Vehicle with same identification code found.\nPlease enter unique identification code!");
        }
    }

    /** Customer_renting_car()
     *Database will have data of only those customers who have rented vehicle. if they return vehicle their data will be deleted.
     * Customer_ID should be UNIQUE
     * Date should be in dd-mm-yyyy format
     * it checks if the given identification code of vehicle is present in vehicle database or not.
     * And if identification code is present then the vehicle is already rented or not is checked.
     */
    public boolean Customer_renting_car(String name_of_customer, String vehicle_identification_code, int phone_number, int customer_id, String Start_Full_Date, String End_Full_Date)
    {
        SimpleDateFormat sdfrmt = new SimpleDateFormat("dd-MM-yyyy");
        sdfrmt.setLenient(false);

        try
        {
            Date startDate = sdfrmt.parse(Start_Full_Date);
            Date endDate = sdfrmt.parse(End_Full_Date);

        }
        catch (ParseException e)
        {
            System.out.println("Entered date is in Invalid Date format");
            return false;

        }
        Customer customer_obj=findCustomer(customer_id);
        if(customer_obj==null) {
            Vehicle is_vehicle_in_list = findVehicle(vehicle_identification_code);
            boolean is_rented_or_not = findVehicleRented(vehicle_identification_code);
            if ((is_vehicle_in_list != null) && (is_rented_or_not == false)) {
                Customer customer1 = new Customer(name_of_customer, vehicle_identification_code, phone_number, customer_id, Start_Full_Date, End_Full_Date);
                Customers.add(customer1);
                for (int i = 0; i < Vehicles.size(); i++) {
                    Vehicle vehicle_obj = Vehicles.get(i);
                    if (vehicle_obj.getIdentification_code().equals(vehicle_identification_code)) {
                        vehicle_obj.setRented_or_not(true);
                        Vehicles.set(i, vehicle_obj);
                        write_to_file();

                    }

                }
                return true;

            } else {
                return false;
            }
        }
        else
        {
            System.out.println("ERROR: Customer with same customer id found.\n Try again with unique customer ID.");
            return false;
        }

    }

    /** findVehicle()
     * Search for a vehicle in arraylist using identification code,
     * if found returns the vehicle object.
     */
    private Vehicle findVehicle(String identification_code)
    {
        for(int i=0;i<Vehicles.size();i++)
        {
            Vehicle vehicle_obj=Vehicles.get(i);
            if(vehicle_obj.getIdentification_code().equals(identification_code))
            {
                return vehicle_obj;
            }

        }
        return null;
    }

    /**
     * search for a customer in arraylist using customer id
     */
    private Customer findCustomer(int Customer_id)
    {
        for(int i=0;i<Customers.size();i++)
        {
            Customer customer_obj=Customers.get(i);
            if(customer_obj.getCustomer_id()==Customer_id)
            {
                return customer_obj;
            }

        }
        return null;
    }

    /** findVehicleRented()
     *Checks if a particular vehicle is rented or not.
     * returns true for rented and false for not rented.
     */
    private boolean findVehicleRented(String identification_code)
    {
        for(int i=0;i<Vehicles.size();i++)
        {
            Vehicle vehicle_obj=Vehicles.get(i);
            if(vehicle_obj.getIdentification_code().equals(identification_code))
            {
              return vehicle_obj.isRented_or_not();
            }

        }
        return false;
    }

    /** write_to_file()
     * this method will write all the data of vehicles and customers to 2 separate files.
     * it will first add headers and then add all data of arraylist using for loop.
     */
    private void write_to_file()
    {
        //for Vehicle file
        try {
            PrintWriter writer = new PrintWriter(Vehicle_File);
            StringBuilder sb = new StringBuilder();
            sb.append("identification_code");
            sb.append(',');
            sb.append("brand");
            sb.append(',');
            sb.append("model");
            sb.append(',');
            sb.append("number_of_seats");
            sb.append(',');
            sb.append("license_plate");
            sb.append(',');
            sb.append("rented");
            sb.append(',');
            sb.append("rent per day");
            sb.append('\n');

            writer.write(sb.toString());


        for(int i=0;i<Vehicles.size();i++)
        {
            Vehicle vehicle_obj=Vehicles.get(i);


                sb = new StringBuilder();
                sb.append(vehicle_obj.getIdentification_code());
                sb.append(',');
                sb.append(vehicle_obj.getBrand());
                sb.append(',');
                sb.append(vehicle_obj.getModel());
                sb.append(',');
                sb.append(vehicle_obj.getNumber_of_seats());
                sb.append(',');
                sb.append(vehicle_obj.getLicense_plate());
                sb.append(',');
                sb.append(vehicle_obj.isRented_or_not());
                sb.append(',');
                sb.append(vehicle_obj.getRent_per_day());
                sb.append('\n');

                writer.write(sb.toString());

            }
            writer.close();
        }
        catch (FileNotFoundException n)
        {
            System.out.println("ERROR_1: File access problem");
        }

        //for customer file
        try {
            PrintWriter writer = new PrintWriter(Customer_File);
            StringBuilder sb = new StringBuilder();
            sb.append("name");
            sb.append(',');
            sb.append("vehicle_code");
            sb.append(',');
            sb.append("phone_no");
            sb.append(',');
            sb.append("customer_id");
            sb.append(',');
            sb.append("start_date");
            sb.append(',');
            sb.append("end_date");
            sb.append('\n');

            writer.write(sb.toString());


            for(int i=0;i<Customers.size();i++)
            {
               Customer customer_obj=Customers.get(i);


                sb = new StringBuilder();
                sb.append(customer_obj.getName_of_customer());
                sb.append(',');
                sb.append(customer_obj.getVehicle_identification_code());
                sb.append(',');
                sb.append(customer_obj.getPhone_number());
                sb.append(',');
                sb.append(customer_obj.getCustomer_id());
                sb.append(',');
                sb.append(customer_obj.getStart_date());
                sb.append(',');
                sb.append(customer_obj.getEnd_date());
                sb.append('\n');

                writer.write(sb.toString());

            }
            writer.close();
        }
        catch (FileNotFoundException n)
        {
            System.out.println("ERROR_2: File access problem");
        }

    }

    /**
     * Will display all vehicles that are in the car rental.
     */
    public void show_all_vehicles()
    {
        System.out.println("Identification code | Brand | Model | Seats | License plate | Rented status | Rent per day");
        for(int i=0;i<Vehicles.size();i++)
        {
            Vehicle vehicle_obj=Vehicles.get(i);

            System.out.println(vehicle_obj.getIdentification_code()+" | "+vehicle_obj.getBrand()+" | "+vehicle_obj.getModel()+" | "+vehicle_obj.getNumber_of_seats()
            +" | "+vehicle_obj.getLicense_plate()+" | "+vehicle_obj.isRented_or_not()+" | "+vehicle_obj.getRent_per_day()+"\n");

        }
    }

    /** carReturn()
     * when a customer returns a car, rent will be calculated based on the number of days the car is used and rent per day of car.
     * the data of the customer will be deleted and the rented status of vehicle is set to false.
     */
    public int carReturn(int cust_id)
    {
        int total_rent=-1;
        for(int i=0;i<Customers.size();i++)
        {
            Customer customer_obj=Customers.get(i);
            if(customer_obj.getCustomer_id()==cust_id)
            {
                Vehicle vehicle_obj=findVehicle(customer_obj.getVehicle_identification_code());
                int rent_per_day=vehicle_obj.getRent_per_day();

                SimpleDateFormat sdf= new SimpleDateFormat("dd-MM-yyyy");
                try {


                    Date d1 = sdf.parse(customer_obj.getStart_date());
                    Date d2 = sdf.parse(customer_obj.getEnd_date());

                    long difference_In_Time = d2.getTime() - d1.getTime();
                    long difference_In_Days = (difference_In_Time
                            / (1000 * 60 * 60 * 24))
                            % 365;
                    total_rent=(int)difference_In_Days*rent_per_day;
                    Customers.remove(i);
                    for(int i2=0;i2<Vehicles.size();i2++)
                    {
                        Vehicle vehicle_obj2=Vehicles.get(i2);
                        if(vehicle_obj2.getIdentification_code().equals(customer_obj.getVehicle_identification_code()))
                        {
                            vehicle_obj2.setRented_or_not(false);
                            Vehicles.set(i2, vehicle_obj2);
                            write_to_file();

                        }

                    }
                }
                catch (java.text.ParseException e)
                {
                    System.out.println("ERROR: Time Calculation Error");
                }
                }
        }
        return total_rent;
    }

    /** deleteVehicle()
     * Vehicle of that identification code will be deleted from the database
     */
    public void deleteVehicle(String id_code)
    {
        for(int i=0;i<Vehicles.size();i++)
        {
            Vehicle vehicle_obj=Vehicles.get(i);
            if(vehicle_obj.getIdentification_code().equals(id_code))
            {
                Vehicles.remove(i);
                write_to_file();

            }

        }
    }

    /** import_from_csv()
     * A csv file named Vehicle_data_import.csv is present. it contains data of vehicles.
     * this method will add all the data from this other file to our file.
     * data in the old file(Vehicle_data.csv) will also be there after importing new data.
     *
     * after import, we can rent the new vehicles also.
     *
     * It will also check the headers of both files if mismatch is found it will display error.
     */
    public void import_from_csv() {
        try{
        String[] headers = null;
        String firstFile = "Vehicle_data.csv";
        Scanner scanner = new Scanner(new File(firstFile));

        if (scanner.hasNextLine())
            headers=scanner.nextLine().split(",");

        scanner.close();
        ArrayList<File>  List_of_files = new ArrayList<>();
        List_of_files.add(new File("Vehicle_data_import.csv"));
        Iterator<File> iterFiles = List_of_files.iterator();
        BufferedWriter writer = new BufferedWriter(new FileWriter(firstFile, true));

        while (iterFiles.hasNext()) {
            File nextFile = iterFiles.next();
            BufferedReader reader = new BufferedReader(new FileReader(nextFile));

            String line = null;
            String[] firstLine = null;
            if ((line = reader.readLine()) != null)
                firstLine = line.split(",");

            if (!Arrays.equals(headers, firstLine))
                throw new Exception("Header mis-match between CSV files: '" +
                        firstFile + "' and '" + nextFile.getAbsolutePath());

            while ((line = reader.readLine()) != null) {
                writer.write(line);
                writer.newLine();
            }

            reader.close();
        }
        writer.close();
            Vehicles=new ArrayList<>();
            Scanner sc = new Scanner(new File("Vehicle_data.csv"));
            sc.useDelimiter("\n");
            Vehicle vehicle_obj;
            sc.nextLine(); //Skip reading Headers;
            while (sc.hasNextLine())
            {
                String data=sc.nextLine();
                String[] array_of_data = data.split(",");
                vehicle_obj=new Vehicle(array_of_data[0],array_of_data[2],array_of_data[1],array_of_data[4],Integer.parseInt(array_of_data[3]),Boolean.parseBoolean(array_of_data[5]),Integer.parseInt(array_of_data[6]));
                Vehicles.add(vehicle_obj);
            }
            sc.close();
    }
    catch(Exception e)
    {
       System.out.println("ERROR: Error while importing "+e);
    }
    }

    public void Write_to_csv()
    {
        write_to_file();
    }

    /** available_vehicle_list()
     * It will display all vehicles that are available for a particular period of time.
     * First it will display all vehicles that are not rented.
     * then it will check the vehicles that are rented, whether those vehicles are available at that required time.
     * and if they are available their data will be displayed.
     */
    public void available_vehicle_list(String start_date,String end_date)
    {
        for(int i=0;i<Vehicles.size();i++)
        {
            Vehicle vehicle_obj=Vehicles.get(i);
            if(vehicle_obj.isRented_or_not()==false)
            {
                System.out.println(vehicle_obj.getIdentification_code()+" | "+vehicle_obj.getBrand()+" | "+vehicle_obj.getModel()+" | "+vehicle_obj.getNumber_of_seats()+" | "+vehicle_obj.getRent_per_day()+"(per day rent)");

            }
        }
        for (int i2=0;i2<Customers.size();i2++)
        {
            Customer customer_obj=Customers.get(i2);
            try{

            SimpleDateFormat sdformat = new SimpleDateFormat("dd-MM-yyyy");
            Date start_cust = sdformat.parse(customer_obj.getStart_date());
            Date start_given = sdformat.parse(start_date);
            Date end_cust=sdformat.parse(customer_obj.getEnd_date());
            Date end_given=sdformat.parse(end_date);

                if(((start_given.compareTo(end_cust)>0) || (start_given.compareTo(start_cust)<0))&&((end_given.compareTo(end_cust)>0) || (end_cust.compareTo(start_cust)<0)))
                {
                    String id_code_of_available_vehicle=customer_obj.getVehicle_identification_code();
                    Vehicle vehicle_obj=findVehicle(id_code_of_available_vehicle);
                    System.out.println(vehicle_obj.getIdentification_code()+" | "+vehicle_obj.getBrand()+" | "+vehicle_obj.getModel()+" | "+vehicle_obj.getNumber_of_seats()+" | "+vehicle_obj.getRent_per_day()+"(per day rent)");

                }

            }
            catch(java.text.ParseException jtp)
            {
                System.out.println("ERROR: problem in date checking!");
            }
        }
    }


}
