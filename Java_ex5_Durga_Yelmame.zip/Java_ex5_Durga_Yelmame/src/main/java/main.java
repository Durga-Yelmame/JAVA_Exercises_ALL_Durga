import java.util.InputMismatchException;
import java.util.Scanner;

/**
 * As per the assignment a menu is created.
 * to perform a particular operation, number assigned to that option should be entered.
 */
public class main {
    public static void main(String args[])
    {
        Car_rental_System car_rent_sys=new Car_rental_System();
        Scanner sc=new Scanner(System.in);
        int Menu_choice=0;
        try
        {
        while(Menu_choice!=9) {


            System.out.println("Menu:" +
                    "\n1.Customer wants to rent" +
                    "\n2.Car Returned by Customer" +
                    "\n3.All Vehicles details" +
                    "\n4.Vehicle available at given dates" +
                    "\n5.Adding new vehicle for rent in system" +
                    "\n6.Cancellation of vehicle from car rental system" +
                    "\n7.Importing vehicle data from new csv file" +
                    "\n8.Write data of Vehicles to a csv" +
                    "\n9.Exit");

            Menu_choice = sc.nextInt();
            switch (Menu_choice) {
                case 1:
                    String Name_of_customer, vehicle_identification_code, Start_date, End_date;
                    int Phone_number, customer_id;
                    System.out.println("Enter Name_of_customer(String), vehicle_identification_code(String),Start_date(dd-mm-yyyy),End_date(dd-mm-yyyy) and Phone_number(Number),customer_id(Number)\n");
                    Name_of_customer = sc.next();
                    vehicle_identification_code = sc.next();
                    Start_date = sc.next();
                    End_date = sc.next();
                    Phone_number = sc.nextInt();
                    customer_id = sc.nextInt();
                    boolean rent_status = car_rent_sys.Customer_renting_car(Name_of_customer, vehicle_identification_code, Phone_number, customer_id, Start_date, End_date);
                    String rent_status_str = rent_status ? "Rent status : Pass" : "Rent status : Failed";
                    System.out.println(rent_status_str);
                    break;
                case 2:
                    System.out.println("Enter Customer ID:");
                    int cust_id = sc.nextInt();
                    int rent = car_rent_sys.carReturn(cust_id);
                    System.out.println("Rent to be paid is: " + rent);
                    break;

                case 3:
                    car_rent_sys.show_all_vehicles();
                    break;
                case 4:
                    System.out.println("Enter Start date and end date in format dd-mm-yyyy: ");
                    String start_date = sc.next();
                    String end_date = sc.next();
                    car_rent_sys.available_vehicle_list(start_date, end_date);
                    break;
                case 5:
                    String identification_code, model, brand, license_plate;
                    int number_of_seats, rent_per_day;
                    System.out.println("Enter identification_code(String),model(String),brand(String),license_plate(String) and number_of_seats(Number) and rent per day\n");
                    identification_code = sc.next();
                    model = sc.next();
                    brand = sc.next();
                    license_plate = sc.next();
                    number_of_seats = sc.nextInt();
                    rent_per_day = sc.nextInt();
                    car_rent_sys.addVehicle(identification_code, model, brand, license_plate, number_of_seats, false, rent_per_day);

                    break;

                case 6:
                    System.out.println("Enter identification_code(String):");
                    String id_code = sc.next();
                    car_rent_sys.deleteVehicle(id_code);
                    System.out.println("Vehicle no longer in rental system!");
                    break;
                case 7:
                    car_rent_sys.import_from_csv();
                    System.out.println("Data imported from new csv(Vehicle_data_import.csv) to old csv(Vehicle_data.csv)");
                    break;
                case 8:
                    car_rent_sys.Write_to_csv();
                    System.out.println("Data Stored in Vehicle_data.csv!");
                    break;
                case 9:
                    System.out.println("Bye!!!");
                    break;
                default:
                    System.out.println("ERROR: You entered wrong choice!");
                    break;


                }
            }
            }
            catch(InputMismatchException inputMismatchException)
            {
                System.out.println("ERROR: String and int data mismatch.\nData entered is invalid please enter appropriate data");
            }

    }
}
