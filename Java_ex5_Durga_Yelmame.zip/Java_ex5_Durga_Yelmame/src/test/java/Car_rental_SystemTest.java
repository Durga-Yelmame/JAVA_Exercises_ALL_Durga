import org.junit.BeforeClass;
import org.junit.Test;

import static org.junit.Assert.*;

/**
 * Before running the test cases delete Vehicle_data.csv and Customer_data.csv
 * Because the data present in those files can interfere with the test case data and make the test cases fail.
 *
 * In this Test class, a new Vehicle is added in car rental system and all tests are performed on that.
 *
 */
public class Car_rental_SystemTest {
   static Car_rental_System car_rental_system;
    @BeforeClass
    public static void setUp()
    {
         car_rental_system=new Car_rental_System();
    }
    @Test
    public void addVehicle() {
        car_rental_system.addVehicle("a123", "Honda", "MiniCar", "MH15432", 4,false,500);
    }

    /**
     * The first test will pass -> as customer can't rent b12345,as it is not available yet.
     * Second test will pass -> as a123 is available.
     * Third test will pass-> as Customer ID is duplicate, it will return false
     * Fourth test pass -> as Car with identification code a123 is already rented, so it will return false
     */
    @Test
    public void customer_renting_car() {

        assertEquals(false,car_rental_system.Customer_renting_car("Durga","b12345",12334,02,"12-11-2021","15-11-2021"));
        assertEquals(true,car_rental_system.Customer_renting_car("Durga","a123",12334,0435,"12-11-2021","15-11-2021"));
     assertEquals(false,car_rental_system.Customer_renting_car("Durga02","autoCar01",12334,01,"12-11-2021","15-11-2021"));
     assertEquals(false,car_rental_system.Customer_renting_car("Sunny","a123",12334465,56,"12-11-2020","15-11-2020"));

    }


 /**First Test pass
  * rent of car is 500 per day
  * days rented- 3 days
  *
  * Second Test shows that as the car is returned it can be rented again(after return the status of rented_or_not is false, so renting it again is possible)
  *Third Test case pass as rent of car is 500 per day
  *   days rented- 4 days
  */
    @Test
    public void carReturn() {

     assertEquals(1500,car_rental_system.carReturn(0435));
        assertEquals(true,car_rental_system.Customer_renting_car("John","a123",12334,456,"12-11-2021","16-11-2021"));
        assertEquals(2000,car_rental_system.carReturn(456));




    }

    /**
     * As the vehicle is deleted from database it cannot be rented.
     *
     */
    @Test
    public void deleteVehicle() {
     car_rental_system.deleteVehicle("a123");
        assertEquals(false,car_rental_system.Customer_renting_car("sam","a123",12334,1456,"12-11-2021","15-11-2021"));


    }


    /**
     * First Test will pass as imported vehicles has car with ee1 code.
     * Second test pass as - rent of ee1 is 3000 per day , days rented is 7
     */
    @Test
    public void import_from_csv() {
        car_rental_system.import_from_csv();
       assertEquals(true,car_rental_system.Customer_renting_car("Sunny","ee1",54747484,023,"23-04-2020","30-04-2020"));
        assertEquals(21000,car_rental_system.carReturn(023));


    }
}