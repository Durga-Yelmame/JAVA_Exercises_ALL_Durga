package Exercise4;

import java.util.*;

public class Main {
    public static void main (String[] args)
    {

        try {
            /**
             * Library constructor will load "Books.csv"
             * Menu will be displayed.
             * user should select which operation he/she wants to perform by entering the number of operation.
             * while loop is used so that multiple operations can be performed in one run without the need to run the code again and again.
             * while loop stops when user enters "6" i.e exit.
             * try catch is used to check for errors when user enters wrong values.
             */
            Library My_library = new Library();
            int choice = 0;
            while (choice != 6) {
                System.out.println("\nOperations that can be performed:" +
                        "\n1.Get titles of all books written by an author -> Input Required : Author Name" +
                        "\n2.All authors of a Book -> Input Required: Book Name" +
                        "\n3.Number of Books written by an author -> Input Required: Author Name" +
                        "\n4.Books published in a given year -> Input Required: Year" +
                        "\n5.Most Prolific Author -> No input required" +
                        "\n6.Exit\n please Enter your choice (eg: 1)");
                Scanner sc = new Scanner(System.in);
                choice = sc.nextInt();
                /**
                 * for every operation a method from Library class is called and output is stored and displayed here.
                 */
                switch (choice) {

                    case 1:
                        System.out.println("1. Alphabetical ascending\n2. Alphabetical Descending\n3. Publication ascending \n4. Publication descending\n5. rating ascending\n6. Rating Descending ");
                        System.out.println("Enter Author Name(Eg: Jane Austen):");
                        sc.nextLine();//to accept enter
                        String author_name = sc.nextLine().trim();
                        ArrayList<Book> book_of_author = My_library.Books_by_given_author(author_name);
                        System.out.println("Enter choice number for display of book List(eg: 1):");
                        int inner_choice = sc.nextInt();
                        /**
                         * output is stored in book_of_author.
                         * Below switch case is used to update output in different formats like asc/desc, alphabetical or year or rating
                         * ArrayList is sorted in switch case
                         */
                        switch (inner_choice) {
                            case 1:
                                Collections.sort(book_of_author, Comparator.comparing(Book::getTitle_of_book));
                                break;
                            case 2:
                                Collections.sort(book_of_author, Comparator.comparing(Book::getTitle_of_book));
                                Collections.reverse(book_of_author);
                                break;
                            case 3:
                                Collections.sort(book_of_author, Comparator.comparing(Book::getYear_of_publication_of_book));
                                break;
                            case 4:
                                Collections.sort(book_of_author, Comparator.comparing(Book::getYear_of_publication_of_book));
                                Collections.reverse(book_of_author);
                                break;
                            case 5:
                                Collections.sort(book_of_author, Comparator.comparing(Book::getAverage_ratings));
                                break;
                            case 6:
                                Collections.sort(book_of_author, Comparator.comparing(Book::getAverage_ratings));
                                Collections.reverse(book_of_author);
                                break;
                            default:
                                System.out.println("You entered invalid choice. System will display in random order");
                                break;
                        }


                        if (book_of_author.isEmpty()) {
                            System.out.println("Author is not in our list or Please check Spelling.");
                            break;
                        }
                        System.out.println("Book List: ");
                        for (int i = 0; i < book_of_author.size(); i++) {
                            Book Book_object = book_of_author.get(i);
                            System.out.println(Book_object.getTitle_of_book() + "\t" + Book_object.getYear_of_publication_of_book() + "\t" + Book_object.getAverage_ratings());
                        }
                        break;

                    case 2:
                        System.out.println("Enter Book Name(Eg: The Lovely Bones):");
                        sc.nextLine();//to accept enter
                        String book_name = sc.nextLine().trim();
                        ArrayList<Author> author_list = My_library.All_Authors_of_book(book_name);

                        if (author_list.isEmpty()) {
                            System.out.println("Book not in our list. or Please check Spelling.");
                            break;
                        }
                        Collections.sort(author_list, Comparator.comparing(Author::getName_of_author));
                        System.out.println("Author List in alphabetical order: ");
                        for (int i = 0; i < author_list.size(); i++) {
                            Author Author_object = author_list.get(i);
                            System.out.println(Author_object.getName_of_author());
                        }
                        break;

                    case 3:
                        System.out.println("Enter Author Name(Eg: J.K. Rowling):");
                        sc.nextLine();//to accept enter
                        String author_name_for_case3 = sc.nextLine().trim();
                        ArrayList<Book> books_of_author = My_library.Books_by_given_author(author_name_for_case3);
                        if (books_of_author.isEmpty()) {
                            System.out.println("Author is not in our list! or Please check Spelling.");
                            break;
                        }
                        System.out.println("Book Count: ");

                        System.out.println(books_of_author.size());

                        break;

                    case 4:
                        System.out.println("Enter Year(eg: 2007):");
                        int year = sc.nextInt();
                        ArrayList<Book> Book_in_that_year = My_library.Books_of_a_year(year);
                        if (Book_in_that_year.isEmpty()) {
                            System.out.println("No Book published in this year.");
                            break;
                        }

                        System.out.println("Book List : ");
                        for (int i = 0; i < Book_in_that_year.size(); i++) {
                            Book Book_object = Book_in_that_year.get(i);
                            System.out.println(Book_object.getTitle_of_book());
                        }
                        break;
                    case 5:
                        String Prolific_author = My_library.Prolific_author_method();
                        System.out.println("Most Prolific Author is: " + Prolific_author);
                        break;
                    case 6:
                        System.out.println("Exit process started....");
                        sc.close();
                        System.out.println("Have a Good Day! Bye!");
                        break;
                    default:
                        System.out.println("ERROR: Entered invalid choice, please refer above options and the number associated with it.");
                        break;

                }

            }
        }
        catch (InputMismatchException e)
        {
            System.out.println("\nERROR : Value Entered by you is wrong.:\n Please enter numbers for year and choice number\n Words for book name and author name!");
        }
    }

}
