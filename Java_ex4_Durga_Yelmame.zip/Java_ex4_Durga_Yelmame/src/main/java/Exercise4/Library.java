package Exercise4;

import java.io.*;
import java.util.*;

/**
 * Library has many books, that's why ArrayList of Book is created
 * This class contains all method that are required to perform operations on Book and Author.
 *
 */
public class Library {
   private final ArrayList<Book> List_of_Books=new ArrayList<>();

   private ArrayList<Author> Book_authors;

    /**
     * Constructor will Load the "Books.csv" file. Path to csv file : Java_ex4_Durga_Yelmame\Books.csv
     * Every Line of csv will be read and stored in "data" variable
     * "data" will be split to get details like author, year of publication, ratings of each book.
     * we can read more fields if we want, but for this assignment only 4 fields are taken.
     *
     * ArrayList of Book is created and data is added in it
     *
     * if File is not found error message will be displayed.
     */
    public Library()  {
        try{
            System.out.println("LOADING Books.csv........");
            Scanner sc = new Scanner(new File("Books.csv"));
            sc.useDelimiter(" ");
            Book Book_object;
            sc.nextLine(); //Skip reading Headers;
            while (sc.hasNextLine())
            {
                String data=sc.nextLine();
                String[] array_of_data = data.split("\t");
                    String[] array_of_authors = array_of_data[7].split(",");
                    Book_authors=new ArrayList<>();
                   for(int j=0;j<array_of_authors.length;j++)
                    {
                       Book_authors.add(new Author(array_of_authors[j]));
                    }
                    Book_object=new Book(array_of_data[10],Float.parseFloat(array_of_data[8]),Float.parseFloat(array_of_data[12]),Book_authors);
                   List_of_Books.add(Book_object);
            }
            sc.close();
        }catch(FileNotFoundException e)
        {
            System.out.println("Error: The file mentioned is not found. \n Solutions: \n1. Store at proper location.\n2. Check name of file.");
        }
    }

    /**
     * Display_all_Book_data() - used to display all data from csv in systematic order.
     */
    public void Display_all_Book_data()
    {
        Book Book_object;
        Author author_object;
        System.out.println("All Details of Book and Author:");
        for(int i=0;i<List_of_Books.size();i++)
        {
            Book_object=List_of_Books.get(i);
            System.out.print("\n\nTitle: "+Book_object.getTitle_of_book()+"\nYear: "+Book_object.getYear_of_publication_of_book()+
                    "\nAverage rating: "+Book_object.getAverage_ratings());
            ArrayList<Author> author_list=Book_object.getAuthor_list_per_book();
            for(int j=0;j<author_list.size();j++)
            {
                author_object=author_list.get(j);
                System.out.print("\nAuthor: "+author_object.getName_of_author());
            }

        }
    }

    /**
     * @param Author_name - input value
     * @return ArrayList<Book> - All books written by author of name "Author_name"
     *
     * Method will go through ArrayList<Author> of every book in library
     * output storage- Book details will be stored in ArrayList of Book
     *
     */
    public ArrayList<Book> Books_by_given_author(String Author_name)
    {
        ArrayList<Book> return_list=new ArrayList<>();
        Book book_object;
        for(int i=0;i<List_of_Books.size();i++)
        {
            book_object=List_of_Books.get(i);
            if(book_object.findAuthor(Author_name)==true)
            {

                return_list.add(new Book(book_object.getTitle_of_book(),book_object.getYear_of_publication_of_book(),book_object.getAverage_ratings()));
            }
        }
        return return_list;
    }

    /**
     * @param book_name - input value.
     * @return all authors of a given book will be returned as ArrayList<Author>
     *     creates a new ArrayList<Author> to store output
     *     If the Books List consist of given title(book_name) then the method getAuthor_list_per_book() will be called
     *     for that title and the output of that method is stored in output ArrayList<Author>
     *         if book is not found, will return empty ArrayList.
     */
    public ArrayList<Author> All_Authors_of_book(String book_name)
    {
       ArrayList<Author> return_list=new ArrayList<>();
        Book book_object;
        for(int i=0;i<List_of_Books.size();i++)
        {
            book_object=List_of_Books.get(i);
            if(book_object.getTitle_of_book().equalsIgnoreCase(book_name))
            {

                return_list=book_object.getAuthor_list_per_book();
            }
        }
        return return_list;
    }

    /**
     * @param year take year as input
     * @return all the books that were published in that year.
     * Method will go through year of publication of every book in library
     *       if it matches with input year, book details will be stored in ArrayList<Book>
     */
    public ArrayList<Book> Books_of_a_year(int year)
    {
        ArrayList<Book> return_list=new ArrayList<>();
        Book book_object;
        for(int i=0;i<List_of_Books.size();i++)
        {
            book_object=List_of_Books.get(i);
            if(book_object.getYear_of_publication_of_book()==year)
            {

                return_list.add(new Book(book_object.getTitle_of_book(),book_object.getYear_of_publication_of_book(),book_object.getAverage_ratings()));
            }
        }
        return return_list;
    }

    /**
     * @return Name of authors who are Prolific authors
     * Prolific author means the author who has published the maximum books
     * Dictionary meaning of Prolific - present in large numbers or quantities
     *
     * Steps: 1. create a ArrayList of all authors. Contain unique author names, no duplicate entries.
     *        2. Check how many books each author from "unique author list" has published. Use Method Books_by_given_author()
     *        3. The author with maximum books count will be returned as output.
     *
     *  If more than 1 author has published maximum count books, then both the names are returned as a single string
     *  Eg: Author A has published 4 books
     *      Author B also has published 4 books
     *      All other remaining authors have published less than 4 books.
     *      Then both A and B will be returned as Prolific authors.
     */
    public String Prolific_author_method()
    {
        ArrayList<String> Unique_Author_value =new ArrayList<>();
        Book book_object;
        for(int i=0;i<List_of_Books.size();i++)
        {
            book_object=List_of_Books.get(i);
            ArrayList<Author> Authors_of_one_book=book_object.getAuthor_list_per_book();
            for(int j=0;j<Authors_of_one_book.size();j++)
            {
                Author Author=Authors_of_one_book.get(j);
                if(Unique_Author_value.contains(Author.getName_of_author())==false)
                {
                    Unique_Author_value.add(Author.getName_of_author());
                }
            }
        }
        String Prolific_author_name="";
        int Max_count_of_books=0;
        for(int i=0;i<Unique_Author_value.size();i++)
        {
            ArrayList<Book> Book_list=Books_by_given_author(Unique_Author_value.get(i));
            int author_book_count=Book_list.size();

            if(author_book_count>Max_count_of_books)
            {
                Max_count_of_books=author_book_count;
                Prolific_author_name=Unique_Author_value.get(i);
            }
           else if(author_book_count==Max_count_of_books)
            {
                Prolific_author_name=Prolific_author_name+" , "+Unique_Author_value.get(i);
            }
        }

        return Prolific_author_name;


    }


}
