package Exercise4;

/**
 * Author Class is used to store the name of author
 * name_of_author is private.
 * Name can be set only using constructor and can be retrieved only using getter
 */
public class Author {
    private String name_of_author;


    /**
     * @param name_of_author
     * trim is used to remove space at the start and end of name.
     * replaceAll is used to remove extra space between First name and Last name.
     */
    public Author(String name_of_author) {
        this.name_of_author = name_of_author.trim().replaceAll("\\s+"," ");;

    }

    public String getName_of_author() {
        return name_of_author;
    }

}
