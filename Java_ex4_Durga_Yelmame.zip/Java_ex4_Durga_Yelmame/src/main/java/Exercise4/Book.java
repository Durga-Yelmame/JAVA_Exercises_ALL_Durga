package Exercise4;

import java.util.ArrayList;
import java.util.Calendar;

/**
 * Book class contains ArrayList of Author Class, Because a book can have one or more authors.
 * Other variables are title, year of publication and rating of each book
 *
 * Year of publication in csv is in decimal but in class it is converted to int, because year cannot be decimal like 2020.4
 * rating is float.
 */
public class Book {

    private String title_of_book;
    private int year_of_publication_of_book;
    private float average_ratings;
    private ArrayList<Author> author_list_per_book=new ArrayList<>();


    /**
     * Constructor to create Book Object ---> includes author list
     * @param title_of_book
     * @param year_of_publication_of_book
     * @param average_ratings
     * @param author_list_per_book
     */
    public Book(String title_of_book, float year_of_publication_of_book, float average_ratings, ArrayList<Author> author_list_per_book) {
        setTitle_of_book(title_of_book);
        setYear_of_publication_of_book(year_of_publication_of_book);
        this.average_ratings = average_ratings;
        this.author_list_per_book = author_list_per_book;
    }

    /**Constructor to create Book Object ---> NOT include author list
     *
     * @param title_of_book
     * @param year_of_publication_of_book
     * @param average_ratings
     */
    public Book(String title_of_book, int year_of_publication_of_book, float average_ratings) {
        this.title_of_book = title_of_book;
        this.year_of_publication_of_book = year_of_publication_of_book;
        this.average_ratings = average_ratings;
    }

    public String getTitle_of_book() {
        return title_of_book;
    }

    public void setTitle_of_book(String title_of_book) {
        this.title_of_book = title_of_book.trim().replaceAll("\\s+"," ");
    }

    public int getYear_of_publication_of_book() {
        return year_of_publication_of_book;
    }

    /**
     * @param year_of_publication_of_book - should be between 0 and 9999. Negative values or values greater than 9999 will be considered invalid
     *
     * if year value is negative or greater than 9999, it will be automatically changed to current year.
     *
     * Some values in "Books.csv" are negative, the books with negative year of publication will be updated to current year
     *
     */
    public void setYear_of_publication_of_book(float year_of_publication_of_book) {
        if(year_of_publication_of_book<0 || year_of_publication_of_book>9999)
        {
            System.out.println("ERROR: Entry of Year of Publication Error \n: The year of publication for "+this.title_of_book+" is INVALID, it is "+year_of_publication_of_book+"\nSystem will set the year for this book as current year i.e : "+Calendar.getInstance().get(Calendar.YEAR) );
                this.year_of_publication_of_book= Calendar.getInstance().get(Calendar.YEAR);
                System.out.println("Year Selected by you: "+this.year_of_publication_of_book);
        }
        else {
            this.year_of_publication_of_book = (int) year_of_publication_of_book;
        }
    }

    public float getAverage_ratings() {
        return average_ratings;
    }

    public ArrayList<Author> getAuthor_list_per_book() {
        return author_list_per_book;
    }

    /**
     * @param author_name - to see if this author is the author of book
     * @return will return true if the author of the book(current book) is author_name(input given to method), otherwise false
     *
     * if a book has multiple authors, this method will successfully check that and return proper results.
     */
    public boolean findAuthor(String author_name)
    {
        for (int i=0;i<author_list_per_book.size();i++)
        {
            Author author=author_list_per_book.get(i);
            if(author_name.equalsIgnoreCase(author.getName_of_author()))
            {
                return true;
            }
        }
        return false;
    }

}
