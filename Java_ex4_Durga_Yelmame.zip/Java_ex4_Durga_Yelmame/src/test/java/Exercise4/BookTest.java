package Exercise4;

import org.junit.Test;

import java.util.ArrayList;
import java.util.Calendar;

import static org.junit.Assert.*;

/**
 * This Test class is used to test the getter and setter of each variable.
 * The Test data is not from "Books.csv". This data is only for testing purpose.
 */
public class BookTest {
    static ArrayList<Author> author_list;
    static Book book,book2;

    /**
     * @BeforeClass is used so that the code setup() runs only once
     */
    @org.junit.BeforeClass
    public static void setup()
    {
        author_list=new ArrayList<>();
        author_list.add(new Author("Megan spark"));
        author_list.add(new Author("John daneil"));
        book=new Book("The world of Magic",1888,(float)4.5,author_list);
        book2=new Book("The world of Magic part 2",1899,(float)4.4,author_list);

    }
    @Test
    public void getTitle_of_book() {
        assertEquals("The world of Magic",book.getTitle_of_book());
    }

    @Test
    public void setTitle_of_book() {
        book2.setTitle_of_book("The world of Magic part 3");
        assertEquals("The world of Magic part 3",book2.getTitle_of_book());
    }

    @Test
    public void getYear_of_publication_of_book() {
        assertEquals(1888,book.getYear_of_publication_of_book());

    }

    @Test
    public void setYear_of_publication_of_book() {
        book2.setYear_of_publication_of_book(-1999);
        assertEquals(2021,book2.getYear_of_publication_of_book());
    }

    @Test
    public void getAverage_ratings() {
        assertEquals((float)4.5,book.getAverage_ratings(),0);
    }


    @Test
    public void findAuthor() {
        assertEquals(true,book.findAuthor("John daneil"));
    }
}