package Exercise4;

import org.junit.Test;

import static org.junit.Assert.*;

/**
 * Code to test getter of Author_name
 */
public class AuthorTest {

    Author author=new Author("Jane Austen");
    @Test
    public void getName_of_author() {
        assertEquals("Jane Austen", author.getName_of_author());

    }
}