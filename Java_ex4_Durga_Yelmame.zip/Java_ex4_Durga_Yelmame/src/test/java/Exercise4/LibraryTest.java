package Exercise4;

import org.junit.Test;
import java.util.ArrayList;
import static org.junit.Assert.*;
/**
 * Two ArrayList are created for each Test method , 1st for actual value that we get from method implementation
 * 2nd is created for expected values.
 *
 * Both ArrayList are compared to check if they have same data
 * if size and data match then test is successful
 * else fail is called and fail message is displayed.
 */
public class LibraryTest {

Library Test_library=new Library();

    /**
     * check prolific authors for given data
     *
     * This test passes successfully.
     */
    @Test
    public void prolific_author_method() {
        Library myLibrary_test=new Library();
        String output="J.K. Rowling , Mary GrandPré";
        assertEquals(output,myLibrary_test.Prolific_author_method());
    }


    /**
     * books_by_given_author() Test - Passed
     */
    @Test
    public void books_by_given_author() {
        ArrayList<Book> Expected_output=new ArrayList<>();
        ArrayList<Book> actual_output=new ArrayList<>();

        Expected_output.add(new Book("The Diary of a Young Girl",1947,(float)4.1));
        actual_output=Test_library.Books_by_given_author("Anne Frank");

        if(Expected_output.size()==actual_output.size())
        {
            for(int i=0;i<Expected_output.size();i++)
            {
                Book Expected=Expected_output.get(i);
                Book Actual=actual_output.get(i);
                assertEquals(Expected.getTitle_of_book(),Actual.getTitle_of_book());
            }
        }
        else
        {
            fail("The size is different means actual output is different from expected output!!! ");
        }
    }

    /**
     * all_Authors_of_book() Test - passed
     */
    @Test
    public void all_Authors_of_book() {
        ArrayList<Author> Expected_output=new ArrayList<>();
        ArrayList<Author> actual_output=new ArrayList<>();

        Expected_output.add(new Author("Stieg Larsson"));
        Expected_output.add(new Author("Reg Keeland"));

        actual_output=Test_library.All_Authors_of_book("The Girl with the Dragon Tattoo (Millennium, #1)");

        if(Expected_output.size()==actual_output.size())
        {
            for(int i=0;i<Expected_output.size();i++)
            {
                Author Expected=Expected_output.get(i);
               Author Actual=actual_output.get(i);
                assertEquals(Expected.getName_of_author(),Actual.getName_of_author());
            }
        }
        else
        {
            fail("The size is different means actual output is different from expected output!!! ");
        }
    }

    /**
     * books_of_a_year() Test - Passed
     */
    @Test
    public void books_of_a_year() {
        ArrayList<Book> Expected_output=new ArrayList<>();
        ArrayList<Book> actual_output=new ArrayList<>();

        Expected_output.add(new Book("Harry Potter and the Prisoner of Azkaban (Harry Potter, #3)",1999,(float)4.53));
        Expected_output.add(new Book("The Perks of Being a Wallflower",1999,(float)4.21));

        actual_output=Test_library.Books_of_a_year(1999);

        if(Expected_output.size()==actual_output.size())
        {
            for(int i=0;i<Expected_output.size();i++)
            {
                Book Expected=Expected_output.get(i);
                Book Actual=actual_output.get(i);
                assertEquals(Expected.getTitle_of_book(),Actual.getTitle_of_book());
            }
        }
        else
        {
            fail("The size is different means actual output is different from expected output!!! ");
        }
    }
}