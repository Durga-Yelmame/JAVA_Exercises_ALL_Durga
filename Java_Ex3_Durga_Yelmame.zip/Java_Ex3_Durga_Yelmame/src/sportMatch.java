import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Scanner;



interface Team
{
	 
	void updatePoints();
	void getTeamName();
	void getPoints();
}


class FootballTeam implements Team 
{
		HashMap<String, Integer> TeamPoints=new HashMap<String , Integer>();
		List<String> sponsors = new ArrayList<>();
	 //constructor of Football team
	 FootballTeam()
	 {
		 try   
		 {  

	         BufferedReader br = new BufferedReader(new FileReader("teams.csv"));
	         String line="";
	         while ((line = br.readLine()) != null)  
			 {  
	        	 String[] data=line.split(",");
	        	 if(data[0].toString().matches("Football"))
				 {
				 TeamPoints.put(data[1].toString(), Integer.parseInt(data[2].toString()));
				 sponsors.add(data[3].toString());		
				 }
			 	
			 } 
			br.close();
			sortPrint(TeamPoints);

		 }   
		 catch (IOException e)   
		 {  
		 e.printStackTrace();  
		 }  
			
	 }

	public void updatePoints() {
		try {
			BufferedReader br = new BufferedReader(new FileReader("results.csv"));
			String line="";
	         while ((line = br.readLine()) != null) 
	         {
 	        	 String[] data=line.split(",");	
	        	 if(TeamPoints.containsKey(data[0].toString()))
	        	 {
	        		 String result_data=data[1].toString();
	        		 int oldPoint=TeamPoints.get(data[0].toString());
	        		 int newPoint=oldPoint;
	        		 switch(result_data)
	        		 {
		        		 case "Win":
		        			 newPoint=newPoint+3;
		        			 break;
		        		 case "Drawn":
		        			 newPoint=newPoint+1;
		        			 break;
	        		 }
        			 TeamPoints.replace(data[0].toString(),oldPoint , newPoint);

	        	 }


	         }
	 			sortPrint(TeamPoints);

			
		} catch (Exception e) {
			
			e.printStackTrace();
		}
		
	}

	public void getTeamName() {
		System.out.println("Team Names of Football:");
		for(Map.Entry m : TeamPoints.entrySet()){    
		    System.out.println(m.getKey());    
		   }  
	}

	public void getPoints() {
		System.out.println("Team Names of Football:");
		for(Map.Entry m : TeamPoints.entrySet()){    
		    System.out.println(m.getValue());    
		   }  	
	}
	
	public void sortPrint(Map<String, Integer> TeamPoints)
	{
		List<Entry<String, Integer>> list = new LinkedList<Entry<String, Integer>>(TeamPoints.entrySet());  
		Collections.sort(list, new Comparator<Entry<String, Integer>>()   
		{  
		public int compare(Entry<String, Integer> o1, Entry<String, Integer> o2)   
		{  
			//return o1.getValue().compareTo(o2.getValue());   ---low to high
			return o2.getValue().compareTo(o1.getValue());  //high to low
		}  
		});  
		//prints the sorted HashMap  
		Map<String, Integer> sortedMap = new LinkedHashMap<String, Integer>();  
		for (Entry<String, Integer> entry : list)   
		{  
			sortedMap.put(entry.getKey(), entry.getValue());  
		}  
		printMap(sortedMap);   
	}
	
	public void printMap(Map<String, Integer> map)   
 	{  
	 	for (Entry<String, Integer> entry : map.entrySet())   
	 	{  
	 	System.out.println(entry.getKey() +"--->  "+entry.getValue());  
	 	}  
	 	System.out.println("\n");  
 	}  
		
	}
//end of football class
 
//class Basketball
 class BasketballTeam implements Team 
 {
	HashMap<String, Integer> TeamPoints=new HashMap<String , Integer>();
 	 //constructor of Basketball team
	 BasketballTeam()
 	 {
 		 try   
		 {  
	         BufferedReader br = new BufferedReader(new FileReader("teams.csv"));
	         String line="";
	         while ((line = br.readLine()) != null)  
			 {  
	        	 String[] data=line.split(",");
	        	 if(data[0].toString().matches("Basketball"))
				 {
				 TeamPoints.put(data[1].toString(), Integer.parseInt(data[2].toString()));
				 }
			  } 
			br.close();
			sortPrint(TeamPoints);
		 }   
		 catch (IOException e)   
		 {  
		 e.printStackTrace();  
		 }  
		 			
 	 }

 	public void updatePoints() {
		try {
			BufferedReader br = new BufferedReader(new FileReader("results.csv"));
			String line="";
	         while ((line = br.readLine()) != null) 
	         {
 	        	 String[] data=line.split(",");	
	        	 if(TeamPoints.containsKey(data[0].toString()))
	        	 {
	        		 String result_data=data[1].toString();
	        		 int oldPoint=TeamPoints.get(data[0].toString());
	        		 int newPoint=oldPoint;
	        		 switch(result_data)
	        		 {
	        		 case "Win":
	        			 newPoint=newPoint+2;
	        			 break;
	        		 
	        		 }
        			 TeamPoints.replace(data[0].toString(),oldPoint , newPoint);
	        	 }
	         }		
				sortPrint(TeamPoints);

		} catch (Exception e) {
			
			e.printStackTrace();
		}
		
	}
 	public void sortPrint(Map<String, Integer> TeamPoints)
	{
		List<Entry<String, Integer>> list = new LinkedList<Entry<String, Integer>>(TeamPoints.entrySet());  
		Collections.sort(list, new Comparator<Entry<String, Integer>>()   
		{  
		public int compare(Entry<String, Integer> o1, Entry<String, Integer> o2)   
		{  
			//return o1.getValue().compareTo(o2.getValue());   ---low to high
			return o2.getValue().compareTo(o1.getValue());  //high to low
		}  
		});  
		//prints the sorted HashMap  
		Map<String, Integer> sortedMap = new LinkedHashMap<String, Integer>();  
		for (Entry<String, Integer> entry : list)   
		{  
		sortedMap.put(entry.getKey(), entry.getValue());  
		}  
		printMap(sortedMap);
		
	} 
		
 	public void printMap(Map<String, Integer> map)   
 	{  
	 	for (Entry<String, Integer> entry : map.entrySet())   
	 	{  
	 	System.out.println(entry.getKey() +"---->  "+entry.getValue());  
	 	}  
	 	System.out.println("\n");  
 	}  
	
 public void getTeamName() {
		System.out.println("Team Names of Basketball:");
		for(Map.Entry m : TeamPoints.entrySet()){    
		    System.out.println(m.getKey());    
		   }  
	}

	public void getPoints() {
		System.out.println("Team Names of Basketball:");
		for(Map.Entry m : TeamPoints.entrySet()){    
		    System.out.println(m.getValue());    
		   }  	
	}
	
 	
 }
 //end of class basketball
 
 
public class sportMatch  {
	public static void main(String[] args) {

		System.out.println("Football Team Names and Scores(Highest First): ");
	 	System.out.println("\n");  
		FootballTeam Fb=new FootballTeam();
		System.out.println("Loaded the results.csv and updating the score:");
	 	System.out.println("\n");  
		System.out.println("Football score after update(Highest First):");
	 	System.out.println("\n");  
		Fb.updatePoints();
		
	 	System.out.println("\n");  
	 	System.out.println("\n");  
		System.out.println("Basketball Team Names and Scores(Highest First): ");
	 	System.out.println("\n");  
		BasketballTeam Bb=new BasketballTeam();
		System.out.println("Loaded the results.csv and updating the score:");
		System.out.println("\n");  
		System.out.println("Bassketball score after update(Highest First):");
	 	System.out.println("\n");  		
		Bb.updatePoints();
	 	
		
	}

}
